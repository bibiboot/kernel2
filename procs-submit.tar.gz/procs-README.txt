WAIPID PROCESS STATUS
=====================

0: The process has been ended successfully.
1: The process has been killed.

KMUTEX
=====
Lock and Unlock thread based on holder.

SUBMITTED BY
============
Kavya
Shakti
Vignesh
Danish

SECTION
======
AM Section
